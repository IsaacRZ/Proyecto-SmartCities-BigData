# 🖥️ Guía: Subir Simulación SUMO a Google Cloud VM

---

## PASO 1 — Crear cuenta en Google Cloud

1. Ve a **cloud.google.com**
2. Haz clic en **"Comenzar gratis"**
3. Inicia sesión con tu cuenta de Google
4. Ingresa tu tarjeta de crédito (no te cobran nada, es solo para verificar identidad)
5. Recibes automáticamente **$300 de crédito gratis** por 90 días

---

## PASO 2 — Crear la Máquina Virtual

1. En el menú izquierdo busca **"Compute Engine"** → **"Instancias de VM"**
2. Haz clic en **"Crear instancia"**
3. Configura lo siguiente:

| Campo | Valor recomendado |
|---|---|
| Nombre | sumo-sanjose |
| Región | us-central1 (Iowa) — más barata |
| Serie | E2 |
| Tipo de máquina | e2-standard-4 (4 CPU, 16GB RAM) |
| Sistema operativo | Windows Server 2022 |
| Disco | 100 GB |

4. Haz clic en **"Crear"**
5. Espera ~2 minutos mientras la VM arranca

---

## PASO 3 — Conectarte a la VM

1. En la lista de instancias verás tu VM con un botón **"RDP"**
2. Haz clic en **"Descargar archivo RDP"**
3. Abre el archivo descargado — se abre el escritorio remoto de Windows
4. Ingresa la contraseña que configuraste al crear la VM
5. ¡Ya estás dentro de la VM! Verás un escritorio de Windows normal

---

## PASO 4 — Instalar SUMO dentro de la VM

Dentro del escritorio remoto:

1. Abre el navegador Edge que viene instalado
2. Ve a **sumo.dlr.de/docs/Downloads.html**
3. Descarga **SUMO 1.26.0 para Windows (64-bit)**
4. Ejecuta el instalador con todas las opciones por defecto
5. Cuando termine, abre CMD y escribe:
```
sumo --version
```
Si ves la versión, SUMO está instalado correctamente.

---

## PASO 5 — Subir tus archivos a la VM

**Opción A — Copiar y pegar directo (más fácil):**
1. En tu PC, comprime toda tu carpeta `Simulacion` en un `.zip`
2. En el escritorio remoto, puedes copiar y pegar archivos directamente desde tu PC a la VM

**Opción B — Google Drive:**
1. Sube el `.zip` a tu Google Drive desde tu PC
2. Dentro de la VM abre el navegador y descárgalo desde Drive

**Opción C — Transferencia RDP:**
1. Al conectarte por RDP, en la pantalla de conexión ve a "Más opciones"
2. Activa "Unidades locales" para que tu PC aparezca como unidad dentro de la VM
3. Copia los archivos directamente

---

## PASO 6 — Ejecutar la simulación

Dentro de la VM:

1. Descomprime el `.zip` en `C:\SUMO_SanJose\`
2. Abre CMD y navega a la carpeta:
```
cd C:\SUMO_SanJose
```
3. Ejecuta el build:
```
build_con_barcelona.bat
```
4. Cuando termine, ejecuta la simulación:
```
sumo-gui -c osm.sumocfg
```
O sin interfaz gráfica (más rápido):
```
sumo -c osm.sumocfg
```

---

## PASO 7 — Guardar y descargar resultados

Los resultados (`edgeData.xml`, `stats.xml`, `tripinfos.xml`) quedan en `C:\SUMO_SanJose\`.

Para descargarlos a tu PC:
- Cópialos desde la VM a tu PC usando la misma conexión RDP
- O súbelos a Google Drive desde dentro de la VM

---

## ⚠️ Importante — Apagar la VM cuando no la uses

La VM cobra por hora encendida. Cuando termines:
1. Ve a Google Cloud → Compute Engine → Instancias
2. Selecciona tu VM → **"Detener"**
3. La VM se apaga y deja de cobrar
4. Tus archivos se mantienen guardados

**Costo estimado:**
- e2-standard-4 = ~$0.13/hora encendida
- Con $300 de crédito tienes ~2,300 horas gratis

---

## ✅ Resumen del flujo completo

```
1. cloud.google.com → Crear cuenta (gratis)
2. Crear VM Windows → e2-standard-4
3. Conectar por RDP → Escritorio remoto
4. Instalar SUMO dentro de la VM
5. Subir carpeta .zip → Descomprimir
6. Ejecutar build_con_barcelona.bat
7. Ejecutar sumo -c osm.sumocfg
8. Descargar resultados
9. DETENER la VM (para no gastar crédito)
```
